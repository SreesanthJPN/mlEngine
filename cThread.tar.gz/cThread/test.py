import numpy as np

a = np.random.rand(100, 2000)
b = np.random.rand(2000, 80000)

c = a@b