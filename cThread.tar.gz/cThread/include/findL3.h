#ifndef GETL3CACHE
#define GETL3CACHE
long getL3Cache();
#endif